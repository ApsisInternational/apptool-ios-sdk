//
//  ApsisOne.h
//  ApsisOne
//
//  Created by Fedor Pudeyan on 2018-12-20.
//  Copyright © 2018 APSIS International AB. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for ApsisOne.
FOUNDATION_EXPORT double ApsisOneVersionNumber;

//! Project version string for ApsisOne.
FOUNDATION_EXPORT const unsigned char ApsisOneVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <ApsisOne/PublicHeader.h>
#import <ApsisOne/ApsisOneAPI.h>

